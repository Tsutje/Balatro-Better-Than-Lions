return {
	disabled_keys = {},
	left_click = false,
}