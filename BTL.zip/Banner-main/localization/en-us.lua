return {
	misc = {
		dictionary = {
			k_bannermod_name = {"Banner"},
			k_bannermod_directions_right = {
				"Right-Click a",
				"card to Ban it",
			},
			k_bannermod_directions_left = {
				"Left-Click a",
				"card to Ban it"
			},
			k_bannermod_incompatible = "Incompatible with",
			b_bannermod_enable_all = {"Enable All"},
			b_bannermod_disable_all = {"Disable All"},

			c_bannermod_left_click = "Left-Click Ban",
		}
	}
}