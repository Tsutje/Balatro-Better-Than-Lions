return {
	["AllBoss"] = true,
	["Dev"] = false,
	["Start_Ante"] = 0,
	["End_Ante"] = 16,
	["HardMode"] = false,
	["UltraHardMode"] = false,
	["Base"] = 100,
	["Blind_Scaling"] = "None",
	["Scaling_Endless"] = true,
	["Blind_Scaling_ID"] = 1,
	["Blind_Custom"] = { --1=small 2=big 3=boss 4=showdown 5=removed
		["Small"] = 1,
		["Big"] = 2,
		["Boss"] = 3,--cant be removed
		["Small_SD"] = false,
		["Small_SDT"] = 4,
		["Big_SD"] = false,
		["Big_SDT"] = 4,
		["Boss_SD"] = true,
		["Boss_SDT"] = 4,
		["ShowdownToggle"] = true,
		["Showdown"] = 4,--only removed if possible
	},
	["Other_Things"] = true
}
