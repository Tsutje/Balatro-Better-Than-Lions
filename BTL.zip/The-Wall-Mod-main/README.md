# **The Wall mod!**

## This *\*awesome\** mod adds cool new features to Balatro!

### Adds lots of blind customization!
Make sure to download the mod at the top!

