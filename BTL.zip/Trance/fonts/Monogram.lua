return {
    render_scale = 10,
    TEXT_HEIGHT_SCALE = 0.83,
    TEXT_OFFSET = {x=10,y=-20},
    FONTSCALE = 0.12,
    squish = 1,
    DESCSCALE = 1
}