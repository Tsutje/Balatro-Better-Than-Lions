return {
    render_scale = 10,
    TEXT_HEIGHT_SCALE = 0.83,
    TEXT_OFFSET = {x=10,y=-5},
    FONTSCALE = 0.11,
    squish = 1,
    DESCSCALE = 1
}