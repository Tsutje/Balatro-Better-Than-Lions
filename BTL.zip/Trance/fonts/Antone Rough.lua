return {
    render_scale = 10,
    TEXT_HEIGHT_SCALE = 0.86,  
    TEXT_OFFSET = {x = 7, y = 6},
    FONTSCALE = 0.06,        
    squish = 0.98,             
    DESCSCALE = 0.98           
}
