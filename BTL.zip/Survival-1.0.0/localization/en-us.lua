return {
    misc = {
        dictionary = {
            k_survival_mode = 'Survival Mode',
            k_survival_info = 'Changes apply to new runs',
            ml_survival_opt = {
                'Disabled',
                'Survival',
                'Survival+',
            }
        }
    }
}