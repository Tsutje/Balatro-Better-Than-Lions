SMODS.Atlas {
    key = "atlas_decks",
    px = 71,
    py = 95,
    path = "jh_decks.png"
  }

SMODS.Back{
    name = "Filmmaker's Deck",
    key = "film_deck",
    pos = {x = 0, y = 0},
	atlas = "atlas_decks",
    config = {
		voucher = "v_directors_cut"
	},
}