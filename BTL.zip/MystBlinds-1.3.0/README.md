a balatro mod that adds several new blinds

# Requirements
Requires the latest version **Steamodded** 1.0.0-BETA.  
Instructions can be found [here](https://github.com/Steamopollys/Steamodded/wiki/01.-Getting-started).

# Installation
Head to the mod's *[Releases](https://github.com/Mysthaps/MystBlinds/releases/latest)* page and download the latest version.  
You can also *clone* this repository, however, some things may break.