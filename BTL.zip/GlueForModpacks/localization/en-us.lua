return {
    misc = {
        dictionary = {
            ---- UI elements ----

            -- Mod Config --
            glue_settings_shop_joker_slots = "Additional Shop Joker Slots",
            glue_settings_voucher_slots = "Additional Voucher Slots",
            glue_settings_booster_slots = "Additional Booster Slots",

            glue_settings_joker_slots = "Additional Joker Slots",
            glue_settings_consumeable_slots = "Additional Cons. Slots",

            glue_settings_joker_rate = "Shop-Joker Spawnrate",

            glue_settings_rarity_rate_Common = "Common Rate",
            glue_settings_rarity_rate_Uncommon = "Uncommon Rate",
            glue_settings_rarity_rate_Rare = "Rare Rate"

        }
    }
}