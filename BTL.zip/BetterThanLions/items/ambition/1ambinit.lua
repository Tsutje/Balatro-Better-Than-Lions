
SMODS.DrawStep {
    key = "ambition_shader",
    order = 11,
    func = function(card, layer)
        if (layer == 'card' or layer == 'both') and card.sprite_facing == 'front' then
            if card.config.center.set == 'ambitioncon' then --replace with whats relevant to you
                card.children.center:draw_shader('booster', nil, card.ARGS.send_to_shader)
            end
        end
    end
}

assert(SMODS.load_file('items/ambition/peace.lua'))()
assert(SMODS.load_file('items/ambition/harmony.lua'))()
assert(SMODS.load_file('items/ambition/solidarity.lua'))()
assert(SMODS.load_file('items/ambition/reflection.lua'))()
assert(SMODS.load_file('items/ambition/sympathy.lua'))()
assert(SMODS.load_file('items/ambition/honor.lua'))()
assert(SMODS.load_file('items/ambition/nobility.lua'))()
assert(SMODS.load_file('items/ambition/unity.lua'))()
assert(SMODS.load_file('items/ambition/commitment.lua'))()
assert(SMODS.load_file('items/ambition/purity.lua'))()
