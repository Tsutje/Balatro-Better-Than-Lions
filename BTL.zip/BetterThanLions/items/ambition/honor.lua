SMODS.Consumable {
    key = 'honor',
    set = 'ambitioncon',
    atlas = 'btlambitionatlas', 
    pos = { x = 1, y = 0 },
	cost = 3,
	unlocked = true,
	discovered = false,
	config = {hand_type = "Straight"},
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.hand_type
            }
        }
    end,
    can_use = function(self, card)
		return true
	end,
	use = function(self, card, area, copier)
        local level = math.ceil(G.GAME.round * G.GAME.round/2)
        if level <= 1 then
            update_hand_text({sound = 'button', volume = 0.7, pitch = 1.1, delay = 0}, { mult = G.GAME.hands[card.ability.hand_type].mult, chips = G.GAME.hands[card.ability.hand_type].chips, handname = card.ability.hand_type, level = ''})
            level_up_hand(card, card.ability.hand_type, nil, level)
            update_hand_text({sound = 'button', volume = 0.7, pitch = 1.1, delay = 0}, {mult = 0, chips = 0, handname = '', level = ''})
        end
	end,
}