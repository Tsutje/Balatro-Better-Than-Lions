SMODS.Booster {
    key = "prestigechoice",
    atlas = "ambitionbooster",
    unskippable = true,
    loc_txt = {
        name = 'Put in The Effort',
        text = {
            "{C:prestigegradient}Choose your Future.{}"
        },
        group_name = 'Life needs a Purpose.'
    },
    pos = {
        x = 0,
        y = 0
    },
    config = {
        extra = 3,
        choose = 1
    },
    cost = 99,
    weight = 0,
    create_card = function(self, card)
        return create_card('prestigecon', G.pack_cards, nil, nil, true, true, nil, "ontheright")
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX('716DE9'))
        ease_background_colour({ new_colour = HEX('605DA6'), special_colour = HEX('64C9CB')})
    end,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.config.center.config.choose, card.ability.extra } }
    end
}