SMODS.Booster {
    key = "ambitionchoice",
    atlas = "ambitionbooster",
    unskippable = true,
    loc_txt = {
        name = 'Shape Yourself',
        text = {
            "{C:ambitiongradient}Make your choice.{}"
        },
        group_name = 'Life waits for Noone.'
    },
    pos = {
        x = 0,
        y = 0
    },
    config = {
        extra = 2,
        choose = 1
    },
    cost = 99,
    weight = 0,
    create_card = function(self, card)
        return create_card('ambitioncon', G.pack_cards, nil, nil, true, true, nil, "heartbeat")
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX('EDC18A'))
        ease_background_colour({ new_colour = HEX('B46F51'), special_colour = HEX('974D39')})
    end,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.config.center.config.choose, card.ability.extra } }
    end
}