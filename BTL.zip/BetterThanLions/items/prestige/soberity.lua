SMODS.Consumable {
    key = 'soberity',
    set = 'prestigecon',
    atlas = 'btlprestigeatlas', 
    pos = { x = 3, y = 0 },
	cost = 3,
	unlocked = true,
	discovered = false,
	config = {},
    loc_vars = function(self, info_queue, card)
        return {
        }
    end,
    can_use = function(self, card)
		return true
	end,
	use = function(self, card, area, copier)
	end,
}