SMODS.Consumable {
    key = 'charity',
    set = 'prestigecon',
    atlas = 'btlprestigeatlas', 
    pos = { x = 8, y = 0 },
	cost = 3,
	unlocked = true,
	discovered = false,
	config = {payout = 35},
    loc_vars = function(self, info_queue, card)
        return { vars = {card.ability.consumeable.payout}
        }
    end,
    can_use = function(self, card)
		return true
	end,
	use = function(self, card, area, copier)
        ease_dollars(card.ability.consumeable.payout)
	end,
}