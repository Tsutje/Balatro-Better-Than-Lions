SMODS.PokerHand {
    key = 'blackj',
    mult = 4,
    chips = 10,
    l_mult = 2,
    l_chips = 10,
    above_hand = "Straight",
    example ={
        { 'S_K', true },
        { 'H_6', true },
        { 'D_5' , true},
    },
    visible = true,
    evaluate = function(parts, hand)
        local count = 0
        local aces = 0
        for _, card in ipairs(hand) do
            local val = card:get_id()
            if val == 14 and not SMODS.has_enhancement(card, "m_stone") then
                aces = aces + 1
                count = count + 11
            elseif val > 10  and not SMODS.has_enhancement(card, "m_stone") then
                count = count + 10
            elseif not SMODS.has_enhancement(card, "m_stone") then
                count = count + val
            elseif SMODS.has_enhancement(card, "m_stone") then
                count = count
            end
        end

        while count > 21 and aces > 0 do
            count = count - 10
            aces = aces - 1
        end

        if count == 21 then
            return { hand }
        else
            return {}
        end
    end
}