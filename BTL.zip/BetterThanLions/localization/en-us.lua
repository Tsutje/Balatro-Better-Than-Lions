return{
    descriptions = {
        
        Planet = {
            c_btl_frost = {
                name = "Frost",
                text= {
                    "{S:0.8}({S:0.8,V:1}lvl.#1#{S:0.8}){} Level up",
                    "{C:attention}#2#",
                    "{C:mult}+#3#{} Mult and",
                    "{C:chips}+#4#{} chips"
                }
            }
        },
        ambitioncon = {
            c_btl_sympathy = {
                name = "Sympathy",
                text = {
                    "{C:ambitiongradient}Unlock{}",
                    "{C:attention}#1#{}"
                }
            },
            c_btl_honor = {
                name = "Honor",
                text = {
                    "{C:ambitiongradient}Unlock{}",
                    "{C:attention}#1#{}"
                }
            },
            c_btl_harmony = {
                name = "Harmony",
                text = {
                    "{C:ambitiongradient}Unlock{}",
                    "{C:attention}#1#{}"
                }
            },
            c_btl_peace = {
                name = "Peace",
                text = {
                    "{C:ambitiongradient}Unlock{}",
                    "{C:attention}#1#{}"
                }
            },
            c_btl_nobility = {
                name = "Nobility",
                text = {
                    "{C:ambitiongradient}Unlock{}",
                    "{C:attention}#1#{}"
                }
            },
            c_btl_solidarity = {
                name = "Solidarity",
                text = {
                    "{C:ambitiongradient}Unlock{}",
                    "{C:attention}#1#{}"
                }
            },
            c_btl_reflection = {
                name = "Reflection",
                text = {
                    "{C:ambitiongradient}Unlock{}",
                    "{C:attention}#1#{}"
                }
            },
            c_btl_commitment = {
                name = "Commitment",
                text = {
                    "{C:ambitiongradient}Unlock{}",
                    "{C:attention}#1#{}"
                }
            },
            c_btl_unity = {
                name = "Unity",
                text = {
                    "{C:ambitiongradient}Unlock{}",
                    "{C:attention}#1#{}"
                }
            },
            c_btl_purity = {
                name = "Purity",
                text = {
                    "{C:ambitiongradient}Unlock{}",
                    "{C:attention}#1#{}"
                }
            }
        },
        prestigecon = {
            c_btl_premier = {
                name = "Premier",
                text = {
                    "{C:prestigegradient}Boss Blinds{}",
                    "now give {C:prestigegradient}Reward Money{}"
                }
            },
            c_btl_maiden = {
                name = "Maiden",
                text = {
                    "{C:prestigegradient}Big Blinds{}",
                    "now give {C:prestigegradient}Reward Money{}"
                }
            },
            c_btl_bliss = {
                name = "Bliss",
                text = {
                    "{C:prestigegradient}Unlock{}",
                    "{C:prestigegradient}The Fool{} {C:tarot}Tarot Card{}"
                }
            },
            c_btl_soberity = {
                name = "Soberity",
                text = {
                    "{C:prestigegradient}Unlock{}",
                    "{C:prestigegradient}The Temperance{} {C:tarot}Tarot Card{}"
                }
            },
            c_btl_contentment = {
                name = "Contentment",
                text = {
                    "{C:prestigegradient}Unlock{}",
                    "{C:prestigegradient}The Hermit{} {C:tarot}Tarot Card{}"
                }
            },
            c_btl_monopoly = {
                name = "Monopoly",
                text = {
                    "{C:prestigegradient}Double Money Cap{}",
                    "{C:inactive}[Current Cap is #1#]{}"
                }
            },
            c_btl_savior = {
                name = "Savior",
                text = {
                    "{C:prestigegradient}Remaining Discards give $1{}"
                }
            },
            c_btl_loved = {
                name = "Loved",
                text = {
                    "{C:prestigegradient}Remaining Hands give $1{}"
                }
            },
            c_btl_humility = {
                name = "Humility",
                text = {
                    "{C:prestigegradient}Unlock Interest{}"
                }
            },
            c_btl_charity = {
                name = "Charity",
                text = {
                    "{C:prestigegradient}+$#1#{}"
                }
            },
        }

    },
    misc = {
        poker_hands = {
            ["btl_blackj"] = "Blackjack",
        },
        poker_hand_descriptions = {
            ["btl_blackj"] = {
                "Cards adds up to {C:attention}21{}",
                "{C:inactive}[Faces = 10, Aces either count as 11 or 1 ]{}"
            },
        }
    }
}