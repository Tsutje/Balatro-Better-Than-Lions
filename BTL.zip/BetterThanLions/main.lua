--- STEAMODDED HEADER
--- MOD_NAME: Better Than Lions
--- MOD_ID: BetterThanLions
--- MOD_AUTHOR: [tje.tsu]
--- MOD_DESCRIPTION: Misc Additions to the Mod Pack
--- BADGE_COLOR: 939CA8
--- PREFIX: btl
--- VERSION: 0.01 [INDEV]
----------------------------------------------
------------MOD CODE -------------------------



assert(SMODS.load_file('items/planets/frost.lua'))()
assert(SMODS.load_file('handtypehandler/blackjack.lua'))()
assert(SMODS.load_file('items/ambition/1ambinit.lua'))()
assert(SMODS.load_file('items/prestige/1preinit.lua'))()
assert(SMODS.load_file('items/booster/ambition.lua'))()
assert(SMODS.load_file('items/tag/ambition.lua'))()
assert(SMODS.load_file('items/booster/prestige.lua'))()
assert(SMODS.load_file('items/tag/prestige.lua'))()
assert(SMODS.load_file('gamehandler.lua'))()




SMODS.Atlas({
	key = "modicon",
	path = "mod_icon.png",
	px = 32,
	py = 32
})


local old = Game.init_game_object;

function Game.init_game_object(G)
  local GAME = old(G);
  GAME.round_resets.ante = 0
  GAME.round_resets.blind_ante = 0
  return GAME
end


SMODS.Atlas{
    key = 'btlplanets',
    path = 'btlplanets.png',
    px = 71,
    py = 95 
}

SMODS.Atlas{
    key = 'btlambitionatlas',
    path = 'btlambition.png',
    px = 71,
    py = 96 
}
SMODS.Atlas{
    key = 'btlprestigeatlas',
    path = 'btlprestige.png',
    px = 71,
    py = 96 
}

SMODS.Shader{
  key = 'ambitionshader',
  path = 'ambition.fs'
}

SMODS.Atlas{
    key = 'ambitionbooster', --Boosters key
    path = 'booster.png',
    px = 62,
    py = 96
}

SMODS.Gradient{
    key = "ambitiongradient",
    colours = {
        HEX("D4957D"),
        HEX("F0CC83")
    }
}
SMODS.Gradient{
    key = "prestigegradient",
    colours = {
        HEX("5D58D9"),
        HEX("64E2CB")
    }
}

loc_colour('')
G.C.ambitiongradient = SMODS.Gradients.btl_ambitiongradient
G.ARGS.LOC_COLOURS.ambitiongradient = G.C.ambitiongradient
G.C.prestigegradient = SMODS.Gradients.btl_prestigegradient
G.ARGS.LOC_COLOURS.prestigegradient = G.C.prestigegradient

SMODS.ConsumableType{
    key = "ambitioncon",
    collection_rows = {5, 5},
    primary_colour = G.C.GOLD,
    secondary_colour = G.C.ambitiongradient,
    loc_txt = {
        collection = "Ambitions",
        name = "Ambition",
        undiscovered = {
            name = "???",
            text = {'Find Yourself, find your {C:ambitiongradient}Ambition{}.'}
        }
    },
    shop_rate = 0.0,
}

SMODS.ConsumableType{
    key = "prestigecon",
    collection_rows = {5, 5},
    primary_colour = G.C.BLUE,
    secondary_colour = G.C.prestigegradient,
    loc_txt = {
        collection = "Prestiges",
        name = "Prestige",
        undiscovered = {
            name = "???",
            text = {'Be a better you, have some {C:prestigegradient}Prestige{}.'}
        }
    },
    shop_rate = 0.0,
}

local can_skip_ref = G.FUNCS.can_skip_booster
G.FUNCS.can_skip_booster = function(e)
    if SMODS.OPENED_BOOSTER and SMODS.OPENED_BOOSTER.config.center.unskippable then
        e.config.colour = G.C.UI.BACKGROUND_INACTIVE
        e.config.button = nil
    else
        return can_skip_ref(e)
    end
end

local oldstartrun = Game.start_run
function Game:start_run(args)
    local g = oldstartrun(self, args)
        if not args.savetext then
            G.GAME.tje_antewantambition = 4
            G.GAME.tje_roundwantprestige = 10
            G.GAME.tje_planetuseburn = 0
            G.GAME.tje_planetburnrate = 0.25
            add_tag(Tag('tag_btl_ambition_tag'))
            add_tag(Tag('tag_btl_prestige_tag'))
            G.E_MANAGER:add_event(Event({
                func = function()
                    for i = #G.playing_cards, 1, -1 do
                        G.playing_cards[i]:remove()
                    end
                    G.GAME.starting_deck_size = #G.playing_cards
                    for i = 1, 5, 1 do
                        add_tag(Tag('tag_draft_drafttag'))
                    end
                    play_sound('generic1', 0.9 + math.random()*0.1, 0.8)
                    return true
                end
            }))
        end
    return g
end
----------------------------------------------
------------MOD CODE END----------------------