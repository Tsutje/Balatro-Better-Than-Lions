#if defined(VERTEX) || __VERSION__ > 100 || defined(GL_FRAGMENT_PRECISION_HIGH)
#define MY_HIGHP_OR_MEDIUMP highp
#else
#define MY_HIGHP_OR_MEDIUMP mediump
#endif

extern MY_HIGHP_OR_MEDIUMP vec2 polychrome;
extern MY_HIGHP_OR_MEDIUMP number dissolve;
extern MY_HIGHP_OR_MEDIUMP number time;
extern MY_HIGHP_OR_MEDIUMP vec4 texture_details;
extern MY_HIGHP_OR_MEDIUMP vec2 image_details;
extern bool shadow;
extern MY_HIGHP_OR_MEDIUMP vec4 burn_colour_1;
extern MY_HIGHP_OR_MEDIUMP vec4 burn_colour_2;

extern MY_HIGHP_OR_MEDIUMP vec2 mouse_screen_pos;
extern MY_HIGHP_OR_MEDIUMP float hovering;
extern MY_HIGHP_OR_MEDIUMP float screen_scale;

extern MY_HIGHP_OR_MEDIUMP float intensity;
extern MY_HIGHP_OR_MEDIUMP float hueShift;

float noise(vec2 p) {
    return fract(sin(dot(p, vec2(27.619, 57.583))) * 43758.5453);
}

vec3 hsl2rgb(vec3 hsl) {
    vec3 rgb = clamp(abs(mod(hsl.x*6.0 + vec3(0.0,4.0,2.0), 6.0)-3.0)-1.0, 0.0, 1.0);
    return hsl.z + hsl.y * (rgb - 0.5) * (1.0 - abs(2.0*hsl.z - 1.0));
}

vec4 effect(vec4 colour, Image texture, vec2 texture_coords, vec2 screen_coords) {
    vec4 base = Texel(texture, texture_coords) * colour;

    // Safely use all externs
    float td_effect = (texture_details.x + texture_details.y + texture_details.z + texture_details.w) * 0.001;
    float img_effect = (image_details.x + image_details.y) * 0.001;
    float dissolve_mod = dissolve * 0.01;
    float polychrome_mod = dot(polychrome, vec2(0.3, 0.7)) * 0.001;
    float shadow_mod = shadow ? 0.02 : 0.0;
    float burn1_mod = (burn_colour_1.r + burn_colour_1.g + burn_colour_1.b) * 0.001;
    float burn2_mod = (burn_colour_2.r + burn_colour_2.g + burn_colour_2.b) * 0.001;

    float roseHue = 0.04 + hueShift;
    float saturation = 0.55;
    float lightness = 0.55;

    float n = noise(texture_coords * 8.0 + time * 0.2);
    float shimmer = smoothstep(0.3, 1.0, n) * intensity;

    float highlight = dot(normalize(vec2(0.6, 0.8)), texture_coords);
    highlight = pow(highlight, 3.0) * 0.25;

    // Combine all "used" values
    float finalL = lightness + highlight + shimmer * 0.15 
                    + dissolve_mod + td_effect + img_effect 
                    + polychrome_mod + shadow_mod + burn1_mod + burn2_mod;

    vec3 rose = hsl2rgb(vec3(roseHue, saturation, clamp(finalL, 0.0, 1.0)));

    return vec4(rose * base.rgb, base.a);
}

#ifdef VERTEX
vec4 position(mat4 transform_projection, vec4 vertex_position) {
    if (hovering <= 0.) {
        return transform_projection * vertex_position;
    }
    float mid_dist = length(vertex_position.xy - 0.5 * love_ScreenSize.xy) / length(love_ScreenSize.xy);
    vec2 mouse_offset = (vertex_position.xy - mouse_screen_pos.xy) / screen_scale;
    float scale = 0.2 * (-0.03 - 0.3 * max(0., 0.3 - mid_dist))
            * hovering * (length(mouse_offset) * length(mouse_offset)) / (2. - mid_dist);

    return transform_projection * vertex_position + vec4(0, 0, 0, scale);
}
#endif
