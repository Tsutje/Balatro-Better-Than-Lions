SMODS.current_mod.calculate = function(self, context)
    G.GAME.tje_antewantambition = G.GAME.tje_antewantambition or 4
    G.GAME.tje_roundwantprestige = G.GAME.tje_roundwantprestige or 10
    local ambitionconsumable = {
    'c_btl_sympathy',
    'c_btl_honor',
    'c_btl_harmony',
    'c_btl_peace',
    'c_btl_nobility',
    'c_btl_solidarity',
    'c_btl_reflection',
    'c_btl_commitment',
    'c_btl_unity',
    'c_btl_purity'
    }
   
    -- Check if ALL consumables are consumed
    local all_consumed = true
    for _, v in ipairs(ambitionconsumable) do
        if not G.GAME.consumeable_usage[v] then
            all_consumed = false
            break
        end
    end

    if context.ante_change then
        if G.GAME.round_resets.ante == G.GAME.tje_antewantambition and not all_consumed then
            G.GAME.tje_antewantambition = G.GAME.tje_antewantambition+4
            add_tag(Tag('tag_btl_ambition_tag'))
        end
    end
    if G.GAME.round == G.GAME.tje_roundwantprestige then
        G.GAME.tje_roundwantprestige = G.GAME.tje_roundwantprestige+10
        add_tag(Tag('tag_btl_prestige_tag'))
    end
    local hand = {
        'Flush',
        'Straight',
        'Four of a Kind',
        'Three of a Kind',
        'Straight Flush',
        'Two Pair',
        'Full House',
        'Flush Five',
        'Five of a Kind',
        'Flush House'
    }
    local consumeable = {
        'c_jupiter',
        'c_saturn',
        'c_mars',
        'c_venus',
        'c_neptune',
        'c_uranus',
        'c_earth',
        'c_eris',
        'c_planet_x',
        'c_ceres'
    }
    for i, v in ipairs(hand) do
        local k = ambitionconsumable[i]
        local p = consumeable[i]

        local old_is_visible = SMODS.is_poker_hand_visible
        function SMODS.is_poker_hand_visible(handname)
            if handname == v and not G.GAME.consumeable_usage[k] then
                return false
            elseif handname == v and G.GAME.consumeable_usage[k] then
                return true
            end
            return old_is_visible(handname)
        end
        local old_eval = SMODS.PokerHands[v].evaluate
        SMODS.PokerHand:take_ownership(v, {
            evaluate = function(parts, hand)
                if not SMODS.is_poker_hand_visible(v) then
                    return {}
                end
                return old_eval(parts, hand)
            end,
        })
        if G.GAME.consumeable_usage[k] then
            SMODS.Consumable:take_ownership(k, {
                in_pool = function() return false end
            }, true)
        end
        SMODS.Consumable:take_ownership(p, {
            in_pool = function() return SMODS.is_poker_hand_visible(v) end
        }, true)
    end
    G.GAME.modifiers.no_blind_reward = G.GAME.modifiers.no_blind_reward or {} 
    if G.GAME.consumeable_usage['c_btl_premier'] then
        G.GAME.modifiers.no_blind_reward.Boss = false
        SMODS.Consumable:take_ownership('c_btl_premier', {
            in_pool = function() return not G.GAME.consumeable_usage['c_btl_premier'] end
        }, true)
    else
        G.GAME.modifiers.no_blind_reward.Boss = true
    end
    if G.GAME.consumeable_usage['c_btl_maiden'] then
        G.GAME.modifiers.no_blind_reward.Big = false
        SMODS.Consumable:take_ownership('c_btl_maiden', {
            in_pool = function() return not G.GAME.consumeable_usage['c_btl_maiden'] end
        }, true)
    else
        G.GAME.modifiers.no_blind_reward.Big = true
    end
    if G.GAME.consumeable_usage['c_btl_bliss'] then
        SMODS.Consumable:take_ownership('c_fool', {
            in_pool = function() return true end
        }, true)
        SMODS.Consumable:take_ownership('c_btl_bliss', {
            in_pool = function() return false end
        }, true)
    else
        SMODS.Consumable:take_ownership('c_fool', {
            in_pool = function() return false end
        }, true)
    end
    if G.GAME.consumeable_usage['c_btl_soberity'] then
        SMODS.Consumable:take_ownership('c_temperance', {
            in_pool = function() return true end
        }, true)
        SMODS.Consumable:take_ownership('c_btl_soberity', {
            in_pool = function() return false end
        }, true)
    else
        SMODS.Consumable:take_ownership('c_temperance', {
            in_pool = function() return false end
        }, true)
    end
    if G.GAME.consumeable_usage['c_btl_contentment'] then
        SMODS.Consumable:take_ownership('c_hermit', {
            in_pool = function() return true end
        }, true)
        SMODS.Consumable:take_ownership('c_btl_contentment', {
            in_pool = function() return false end
        }, true)
    else
        SMODS.Consumable:take_ownership('c_hermit', {
            in_pool = function() return false end
        }, true)
    end
    if G.GAME.consumeable_usage['c_btl_loved'] then
        G.GAME.modifiers.no_extra_hand_money = false
        SMODS.Consumable:take_ownership('c_btl_loved', {
            in_pool = function() return not G.GAME.consumeable_usage['c_btl_loved'] end
        }, true)
    else
        G.GAME.modifiers.no_extra_hand_money = true
    end
    if G.GAME.consumeable_usage['c_btl_humility'] then
       G.GAME.modifiers.no_interest = false
        SMODS.Consumable:take_ownership('c_btl_humility', {
            in_pool = function() return not G.GAME.consumeable_usage['c_btl_humility'] end
        }, true)
    else
        G.GAME.modifiers.no_interest = true
    end
    if G.GAME.consumeable_usage['c_btl_savior'] then
        SMODS.Consumable:take_ownership('c_btl_savior', {
            in_pool = function() return not G.GAME.consumeable_usage['c_btl_savior'] end
        }, true)
    end
    if context.using_consumeable and context.consumeable.config.center.set == "Planet" then
        G.GAME.tje_planetuseburn = G.GAME.tje_planetuseburn+G.GAME.tje_planetburnrate
        print(4-G.GAME.tje_planetuseburn)
    end
end