return {
	["use"] = true,
    ["animation"] = true,
    ["reduce"] = false,
    ["unlock_all"] = false,
    ["stake_colour"] = 1,
    ["stake_select"] = 1
}