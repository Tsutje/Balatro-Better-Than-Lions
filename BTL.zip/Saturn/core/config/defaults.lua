return {
  -- Stat-Tracking
  track_stats = false,
  track_money_gen = false,
  track_value_gen = false,
  track_card_gen = false,
  track_jokers_rem = false,
  track_cards_add = false,
  track_cards_rem = false,
  track_retriggers = false,
  track_hands_upgraded = false,
  track_jokers_gen = false,
  track_turned_gold = false,
  track_plus_hands = false,

  -- Rem-Animations
  remove_animations = false,
  enable_dramatic_final_hand = false,
  enable_animation_skip_pause = false,

  -- stacking
  enable_stacking = false,

  -- deck viewer
  hide_played = false,
}
