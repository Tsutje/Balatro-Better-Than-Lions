# Greener-Jokers
<img width="1144" height="863" alt="image" src="https://github.com/user-attachments/assets/d8cfe408-4dcb-4770-9c87-ef5ae1b237fe" />

A Balatro mod I've been working on for a little over a month! Contains 75 unique Jokers, 10 custom Challenges, and 5 new Decks, fully complete with custom art.
Greener Jokers is designed with a Vanilla+ mindset, meaning there are no new mechanics such as Enhancements or Seals, so it should be able to fit cleanly into any other assortment of mods you're playing with! If there are any issues, reach out to me on Discord @abuffzucchini

Additional Credits:

Art: Crispybag, DanTKO, dewdrop, GlerG, gooseberry, NoahCrawfish, PPNyan, the_orang_man, Tobyaaa, Worldwaker2

Concepts: Bissy, Crispybag, gooseberry, NoahCrawfish, Tobyaaa, Worldwaker2, Xolimono

Playtesting: B1ackZer0, gooseberry, NoahCrawfish, the_orang_man, Tobyaaa, Worldwaker2

Special Thanks: base4, Clover


Code Help: sunsetquasar, Vitellary, Astra, nh6574, BakersDozenBagels, AuroraAquir, Somethingcom515, N'
