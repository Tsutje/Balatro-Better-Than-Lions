return {
  
    misc = {
      challenge_names = {
        c_znm_fourfingers = "Oligodactyly",
        c_znm_blueberry = "Turnover of the Century",
        c_znm_tunasalad = "Tuna Salad",
        c_znm_shrimpfest = "Shrimpfest",
        c_znm_multilevelmarketing = "Multi Level Marketing",
        c_znm_geodeposit = "Geo Deposit",
        c_znm_housingcrisis = "The 2000's Balatro Full House Crisis",
        c_znm_counting = "Counting with Bissy",
        c_znm_dizzydiving = "Dizzy Diving",
        c_znm_uno = "Uno",
      },
       v_text = {
         ch_c_znm_fourfingers = {"Can only select 4 cards"},
         ch_c_znm_foreverberry = {'{C:attention}Blueberries{} lasts a little bit "longer"!'},
         ch_c_znm_tunasalad = {"Selling a card costs {C:money}$10{}"},
         ch_c_znm_pyramid = {"{C:attention}Pyramid Scheme{}'s chance is {C:green}1 in 2{}"},
         ch_c_znm_evilreef = {"Playing a {C:attention}debuffed{} card sets money to {C:money}$0{}"},
        ch_c_znm_volcanorule = {"Playing a {C:attention}debuffed{} card sets money to {C:money}$0{}"},
       }
    }
}

