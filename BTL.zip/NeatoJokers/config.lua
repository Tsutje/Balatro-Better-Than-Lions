return {
    hatsune_musicu = 3
}
