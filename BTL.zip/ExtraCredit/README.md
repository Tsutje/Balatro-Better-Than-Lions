Extra Credit!

A small-scale vanilla-style content mod for Balatro University

Features:
- 45 jokers with new effects and art :)
- 3 cool new decks too!

Project Lead:
- CampfireCollective

Programming:
- CampfireCollective
- Stupid
- MathIsFun_

Art:
- kittyknight
- UselessReptile8
- Wingcap
- HonuKane
- bishopcorrigan
- tuzzo
- R3venantR3mnant
- Neato
- Sacto
- Gote
- CampfireCollective

Concepting:
- CampfireCollective
- kittyknight
- Audrizzle
- Neon
- Expelsword
- tuzzo
- bishopcorrigan
- Wingcap
- AlasBabylon
- HonuKane
- conk reet
- Sacto
- BioSector
- Splatter_Proto
- SenrabMJam
- Stupid
- AviolosAvali
- Xilande
- Sbubby
- Seadubbs
- Swordodo

Special thanks:
- Drspectred
- Djynasty
- InertSteak
- Akai
- localthunk


If you're supposed to be on this list somewhere and aren't, please reach out to me on discord! My username is campfirecollective
